---
name: ContextAtlas
colors:
  surface: '#0d141d'
  surface-dim: '#0d141d'
  surface-bright: '#333a44'
  surface-container-lowest: '#080f18'
  surface-container-low: '#151c26'
  surface-container: '#19202a'
  surface-container-high: '#242a34'
  surface-container-highest: '#2e353f'
  on-surface: '#dce3f0'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dce3f0'
  inverse-on-surface: '#2a313b'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#ecb2ff'
  on-secondary: '#520071'
  secondary-container: '#cf5cff'
  on-secondary-container: '#480063'
  tertiary: '#f4f5ff'
  on-tertiary: '#193053'
  tertiary-container: '#c8daff'
  on-tertiary-container: '#4a5f85'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#f8d8ff'
  secondary-fixed-dim: '#ecb2ff'
  on-secondary-fixed: '#320047'
  on-secondary-fixed-variant: '#74009f'
  tertiary-fixed: '#d6e3ff'
  tertiary-fixed-dim: '#b1c7f2'
  on-tertiary-fixed: '#001b3d'
  on-tertiary-fixed-variant: '#31476b'
  background: '#0d141d'
  on-background: '#dce3f0'
  surface-variant: '#2e353f'
  surface-cobalt: '#0D192C'
  success-matrix: '#39FF14'
  warning-cyber: '#FF9900'
  error-neon: '#FF3131'
  text-lavender: '#A5B4FC'
  text-indigo: '#6366F1'
typography:
  display-lg:
    fontFamily: JetBrains Mono
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
  hud-stat:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: '0'
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter-canvas: 30vh
  side-panel-width: 400px
---

## Brand & Style

The design system is a high-precision, overlay-first topology HUD designed to provide a semantic debug layer over active applications. The brand personality is mathematically rigorous, professional, and mechanical, evoking the feeling of a sophisticated instrument panel or a real-time engineering telemetry suite.

The visual style is a fusion of **Minimalism** and **Glassmorphism**, referred to internally as "Frozen Neon Glass." It utilizes deep, light-absorbent backgrounds contrasted with high-vibrancy neon accents to represent interactive mapping beams and system topology. The core interaction model relies on "Atlas Blinds"—progressive reveal panels that slide from the viewport edges to present different abstraction layers (L0-L5) without obscuring the host application's context.

The visual anchor is the connected **cA sphere logo**, where the 'c' and 'A' are physically joined to represent unified celestial topology, with mathematical compass geometry integrated into the 'A' letterform.

## Colors

The palette is strictly functional, optimized for high contrast in technical environments.

- **Primary (Electric Cyan):** Represents the "mapping beam." Used for active interactivity, hover states, and critical HUD focuses.
- **Secondary (Digital Ultraviolet):** Represents deep system topology and engineering-specific layers (L4–L5).
- **Surface (Frosted Midnight Cobalt):** The standard container color, utilized with backdrop blurs to maintain context of the underlying application.
- **Background (Deep Space Obsidian):** The root base for all panels, ensuring maximum text legibility.
- **Functional States:** Matrix Green (High Confidence), Cyber Orange (Low Confidence/Warning), and Neon Red (Critical Error/Broken Path) provide immediate semantic feedback.

## Typography

This design system employs a dual-font strategy to separate technical data from human-readable content.

- **JetBrains Mono:** The technical voice. Used for coordinates, system metrics, and structural headers. It reinforces the mathematical alignment of the HUD.
- **Inter:** The human voice. Used for evidence reports, descriptions, and user-generated notes.

All typography must align to a 4px vertical grid. Large display headers use tight negative tracking to feel architecturally solid, while technical labels (`label-caps`) use wide tracking to ensure clarity at small sizes.

## Layout & Spacing

The layout is a viewport-anchored HUD that wraps around the host application. It uses a 4px baseline rhythm.

### Layout Model
- **L0 Top Blind:** Slides down from the top edge (max height 40% of viewport).
- **L1-L5 Bottom Blind:** Slides up from the bottom edge (max height 60% of viewport).
- **Core Canvas Gutter:** A protected central viewing area of at least 30% viewport height must remain clear to allow interaction with the host app.
- **Side Panel:** A 400px fixed-width inspector for deep YAML schemas, sliding in from the right.

Information density is high. Use 1px dividers (`#1A3154`) instead of large margins to separate data rows. On mobile, blinds transition to full-screen vertical modals with 48px touch targets.

## Elevation & Depth

Depth is conveyed through **Glassmorphic Opacity Stacking** rather than traditional drop shadows.

- **Surface Layers:** Panels use `backdrop-filter: blur(20px)` and a default 70% opacity. 
- **Z-Axis Hierarchy:** When panels stack, the underlying layers increase in opacity to provide visual separation.
- **Outlines:** All containers are defined by 1px "Steel Blue" hairline borders (`#1A3154`). 
- **Active States:** Elevation is signified by light emission (glows) rather than shadows. Active primary buttons and pins emit a 12px blur radius glow in Electric Cyan.

## Shapes

The shape language reflects structural engineering precision. 

- **Technical Elements:** Buttons and small HUD tags use a sharp 2px (`sm`) or 4px (`default`) radius.
- **Containers:** Larger cards and blinds use an 8px (`md`) radius to slightly soften the interface while maintaining a disciplined, geometric feel.
- **Interactive Markers:** The `AtlasPin` is circular to differentiate it from the rectangular HUD layout.

## Components

### Buttons
- **Primary:** Solid Electric Cyan fill, JetBrains Mono Bold text in Obsidian. Features a cyan outer glow on hover.
- **Secondary:** Transparent background with a 1px Steel Blue border. Text in Electric Cyan.

### Atlas Blinds & Tabs
- **Pull Tabs:** 48px draggable handles at the top/bottom centers. Contains a minimal arrow and the layer label (e.g., `L0 PUBLIC`).
- **Layer Control:** A horizontal instrument-style toolbar. Active L0 tabs glow cyan; L1-L5 tabs glow ultraviolet.

### AtlasPin
- A glowing 16px circular marker containing the cA sphere. Upon interaction, it expands into a frosted glass card showing coordinate addresses and confidence scores.

### Inputs & Sliders
- **Inputs:** Frosted Cobalt background with a Steel Blue border. Focus state triggers an Electric Cyan border and halo.
- **Opacity Dial:** A specialized slider track with a gradient from transparent to 90% opaque. The thumb is a 12px Electric Cyan square.

### Data Displays
- **EvidenceStrip:** Compact technical icons in a row that expand into file paths on hover.
- **CoordinateInspector:** A right-aligned panel for YAML data scanning, using monospace fonts and left-aligned keys for rapid auditing.