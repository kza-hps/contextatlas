---
name: Ancient Mapmaking for the AI Age
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393e'
  surface-container-lowest: '#0d0e13'
  surface-container-low: '#1a1b20'
  surface-container: '#1e1f25'
  surface-container-high: '#292a2f'
  surface-container-highest: '#33343a'
  on-surface: '#e3e2e9'
  on-surface-variant: '#d2c5b1'
  inverse-surface: '#e3e2e9'
  inverse-on-surface: '#2f3036'
  outline: '#9b8f7d'
  outline-variant: '#4e4637'
  surface-tint: '#f0bf5c'
  primary: '#f0bf5c'
  on-primary: '#412d00'
  primary-container: '#c89b3c'
  on-primary-container: '#4b3500'
  inverse-primary: '#7b5900'
  secondary: '#5de6ff'
  on-secondary: '#00363e'
  secondary-container: '#00cbe6'
  on-secondary-container: '#00515d'
  tertiary: '#d1bcff'
  on-tertiary: '#3c0090'
  tertiary-container: '#b08fff'
  on-tertiary-container: '#4600a5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea4'
  primary-fixed-dim: '#f0bf5c'
  on-primary-fixed: '#261900'
  on-primary-fixed-variant: '#5d4200'
  secondary-fixed: '#a2eeff'
  secondary-fixed-dim: '#2fd9f4'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#004e5a'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d1bcff'
  on-tertiary-fixed: '#23005b'
  on-tertiary-fixed-variant: '#5700c9'
  background: '#121318'
  on-background: '#e3e2e9'
  surface-variant: '#33343a'
  void-black: '#05060A'
  obsidian-navy: '#101827'
  dark-slate: '#1A2130'
  brass-gold: '#C89B3C'
  signal-cyan: '#22D3EE'
  atlas-violet: '#7B3FF2'
  coordinate-magenta: '#D946EF'
  graphite: '#2A2F3A'
  mist-grey: '#A7B0C0'
  fine-line-grey: '#445064'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-bold:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-code:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  headline-md-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  grid-unit: 4px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
  panel-padding-lg: 32px
  widget-padding-sm: 12px
---

## Brand & Style

The design system is a sophisticated fusion of **Minimalism** and **Glassmorphism**, structured with the absolute technical rigor of a drafting grid. It evokes the feeling of "ancient mapmaking for the AI age"—marrying the precise, cartographic beauty of historical atlases with the sleek, luminous indicators of modern active systems.

The UI is grounded in a deep spatial void, suggesting an infinite landscape over which context can be plotted. It uses frosted-glass surfaces, thin borders, and topological route lines to create a premium, operational atmosphere. The brand personality is calm, clear, and record-aware, avoiding sci-fi tropes in favor of professional, administrative clarity.

### Core Visual Principles:
- **Spatial Depth:** Using layered transparencies and backdrop blurs rather than heavy shadows to denote elevation.
- **Drafting Rigor:** A disciplined 4px baseline grid and fine-line geometry suggest technical accuracy.
- **Cartographic Arcs:** Subtle network sphere geometry and curved route lines soften the rigid grid.
- **Luminous Intent:** Accents are treated as "signals"—light used functionally to indicate active coordinates or evidence.

## Colors

This design system operates in a **default dark mode**. The color palette is categorized into foundations, cartographic accents, and functional signals.

### Foundations
- **Void Black & Obsidian Navy:** Form the deep spatial background and primary container surfaces.
- **Dark Slate:** Used for elevated panels and hover states.

### Accents
- **Brass Gold (Primary):** Represents the historical "atlas" element. Used for brand markers, compass geometry, and premium interactive highlights.
- **Signal Cyan (Secondary):** Used for active coordinates, success states, and live evidence markers.
- **Atlas Violet (Tertiary):** Dedicated to AI/Developer context, prompts, and agent-specific workflows.

### Utility
- **Coordinate Magenta:** Reserved for focus/attention markers, such as stale nodes or items in the review queue.
- **Neutral Greys:** Graphite and Fine Line Grey define the structure, used for borders and drafting grids.

## Typography

Typography is used to distinguish between human-readable intent and machine-readable evidence.

- **Inter:** The primary workhorse for the UI. It provides clarity for journey stages, roles, and status. It ensures the L0 experience remains accessible to non-technical users.
- **JetBrains Mono:** Used sparingly for technical "coordinates," aliases, route patterns, and system identifiers. This distinguishes "evidence" from "meaning."

### Usage Notes:
- **Display fonts** are rare, reserved for brand entry points.
- **Label Caps** should always be used for metadata headers and column titles to enhance scanability.
- **Line heights** are generous (1.5x) for body text to reduce glare on high-contrast dark screens.

## Layout & Spacing

The design uses a **Fluid Grid** model centered on a 4px/8px drafting-grid rhythm. The system is designed to sit on top of host products as an overlay.

### Layout Model:
- **Atlas Blinds:** Navigation and deep-layer data are managed through top-down and bottom-up overlays ("blinds").
- **12-Column Grid:** For the expanded workbench (L1-L5), content follows a standard 12-column structure with 16px gutters.
- **Desktop (1025px+):** Employs the full dual-blind system with a right-side Coordinate Inspector.
- **Mobile (Up to 640px):** Blinds transition to full-screen drawers. Horizontal journey maps collapse into a 3-step "focused" view (Previous -> Current -> Next).

### Breakpoints:
- **Mobile:** 640px (Margins: 20px)
- **Tablet:** 1024px (Margins: 32px)
- **Desktop:** 1440px (Max content width, centered)

## Elevation & Depth

Visual hierarchy is conveyed through **Glassmorphism** and **Tonal Layering** rather than traditional drop shadows.

- **L0 (Journey Surface):** Highest transparency with light backdrop blur (4px). Feels like a thin film on top of the host page.
- **Workbench Panels:** Obsidian Navy surfaces with heavy backdrop blur (12px-16px). These panels feel more substantial and "grounded."
- **Low-Contrast Outlines:** Every container uses a 1px "Fine Line" border. For active items, this border transitions to a Signal Cyan or Brass Gold glow.
- **Handle Geometry:** Centered pill handles on the edges of blinds indicate the ability to pull or slide.

## Shapes

The shape language combines **Rounded (0.5rem)** corners for standard UI components with **Pill-shaped (Full)** corners for badges and status chips.

- **Cards/Panels:** 0.5rem (rounded) for a professional, balanced feel.
- **Status Chips:** Full pill shape to distinguish them from interactive buttons.
- **L0 Header:** Subtle rounding (0.25rem) to maintain a "strip" appearance that aligns with the host page edges.
- **Network Nodes:** Perfect circles used in sphere geometry and journey markers.

## Components

### L0 Journey Header
The "Product Wedge." A compact banner containing a role badge, journey strip, and "You are here" marker. It must include a copyable Atlas Pin action.

### Atlas Pins / Waypoints
Small branded markers (Compass icon + Coordinate). Hovering expands to reveal route/status/role context. Clicking triggers a "Copied" animation using Signal Cyan.

### Status Chips
Compact pill-shaped labels. Use Fine Line Grey for neutral statuses, Signal Cyan for "Ready," and Coordinate Magenta for "Stale" or "Review Needed."

### Atlas Blinds
Vertical overlays with integrated drag handles.
- **Top Blind:** Public journey maps, expanded L0.
- **Bottom Blind:** L1-L5 Workbench. Includes tabs for Page, Workflow, Data, Platform, and AI layers.

### Buttons
Primary buttons use Brass Gold or Signal Cyan borders with Obsidian Navy backgrounds. They should feel "etched" into the UI rather than sitting on top.

### Coordinate Inspector
A right-side persistent panel for desktop. Uses a dense, monospaced layout to show evidence, confidence scores, and narrow AI scope suggestions.