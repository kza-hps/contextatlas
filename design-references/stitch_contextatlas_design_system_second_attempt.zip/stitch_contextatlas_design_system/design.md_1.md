# ContextAtlas DESIGN.md

## Product

ContextAtlas is a repo-native topology discovery and classification engine for AI-assisted software teams.

It discovers product surfaces, routes, dependencies, workflows, evidence, and implementation layers, then turns them into stable coordinates and shareable layered maps.

The core product experience is not a dashboard.

The core product experience is an overlay-first topology HUD that appears over a live website, app, local preview, or product surface. The user should still see the product itself. ContextAtlas adds meaning, coordinates, routes, confidence, evidence, and deeper technical context through subtle pull tabs, Atlas Pins, coordinate badges, and draggable Atlas Blinds.

The product should feel like a map room projected over the software itself.

## Core metaphor

ContextAtlas is an atlas for software context.

It combines:

- cartography
- coordinate systems
- topology
- semantic maps
- product journeys
- code architecture
- evidence trails
- AI-readable context

It should feel like:

- Stripe Workbench for precise product and operational context
- Minecraft F3 for always-available debug truth over the thing being used
- a git client or observability console for evidence, status, and review
- a transparent browser overlay rather than a separate destination

The live app remains the main surface. ContextAtlas is the intelligent map layer above and below it.

## Primary interaction model: Atlas Blinds

The key UI metaphor is a set of pull-down / pull-up blinds.

These should feel more like elegant translucent blinds than ordinary modals or drawers.

The blinds reveal more context as the user pulls them open.

### Collapsed state

The live product is fully visible.

Only small Atlas pull tabs, Atlas Pins, or coordinate markers are visible.

The user can still use the underlying product normally.

### Peek state

A thin HUD appears.

It shows the current coordinate, route, label, layer, confidence, and maybe a short “where am I?” explanation.

This is the quick orientation state.

### Top blind: L0 Map

The top blind pulls down.

This is the most important first-user experience.

It reveals the L0 public-facing map: the simplest, most human-readable view of where the user is in the product journey.

The L0 map should help non-technical users orient themselves.

It should answer:

- What is this place in the product?
- Who is this surface for?
- What is the user trying to do here?
- What journey step is this?
- What are the nearby steps?
- What coordinate identifies this place?
- What can I copy or share?

L0 is the public-facing and product-facing layer.

It is for founders, marketers, support people, designers, recruiters, customers, stakeholders, and AI assistants that need the clean journey-level explanation.

It should avoid exposing private implementation detail by default.

### Bottom blind: L1-L5 Workbench

The bottom blind pulls up.

This is for admin, engineers, QA, product operators, and AI coding agents.

It reveals deeper implementation layers:

- L1: pages, routes, layouts, UI components
- L2: workflows, states, permissions, notifications, business logic
- L3: data, tables, records, auth, storage, policies
- L4: integrations, APIs, webhooks, infrastructure, deployments
- L5: tests, UAT notes, prompts, runbooks, AI context exports

The bottom blind should answer:

- Why does ContextAtlas think this coordinate is correct?
- What evidence supports this classification?
- What files, routes, records, services, and tests connect to it?
- What does an engineer or AI coding agent need to know?

### Full review state

The top and bottom blinds can expand further or meet.

This is used for:

- uncertain mappings
- stale coordinates
- split / merge decisions
- review queues
- dense evidence inspection
- coordinate editing
- admin workflows

This state can be more opaque because the user is actively reviewing or editing context.

## Blind opacity and transparency

The blinds should have an elegant opacity control.

This can be a simple slider, dial, or small glass-control toggle.

States:

- Transparent: the product surface remains highly visible
- Frosted: readable but still contextual
- Opaque: used for review, editing, or dense technical inspection

The opacity control should feel premium and calm, not gimmicky.

The core principle is:

The product surface is the context. Never cover it unnecessarily.

## Layer Zero: the MAP

Layer Zero is the first thing the user should understand.

At L0, ContextAtlas should show a clean MAP.

This MAP is not a technical graph. It is the easiest orientation view.

It should feel like a user journey map, product terrain map, or route map.

It should show:

- current product location
- current coordinate
- journey step
- actor
- intent
- state
- nearby journey nodes
- previous and next likely steps
- public-facing label
- plain-language explanation
- share / copy actions

The L0 map is the shareable layer.

It can be shared with:

- marketing
- product
- support
- founders
- ChatGPT
- Claude
- Codex
- customers
- stakeholders

L0 should be beautiful, legible, and screenshot-ready.

It should let a user point to a page and say:

“This is where we are in the product.”

## Deeper layers

The deeper layers are progressively revealed.

They should not overwhelm the L0 experience.

L1-L5 belong primarily to admin, engineers, QA, support operations, and AI agents.

They should be accessible through the bottom blind, layer controls, evidence strips, inspectors, and review modes.

The UI should clearly distinguish:

- public journey meaning
- product/interface structure
- workflow logic
- data architecture
- integrations
- tests and AI operations

## Coordinate model

Coordinates are stable neutral addresses.

Format:

CA:{ORG}:{PROPERTY}:{NODE}

Example:

CA:KZA:VOUCHME:N00042

The coordinate identifies the node.

Meaning lives beside the coordinate as metadata:

- aliases
- labels
- actor
- intent
- state
- layer
- evidence
- route
- source files
- confidence
- relationships

The user should not need to manually understand coordinates.

They should be able to:

- paste a URL
- copy an Atlas Pin
- click a coordinate badge
- ask “where is this?”
- share the visible context with an AI assistant

## Core components

Design a system for:

- Atlas Pin
- Coordinate Badge
- Top L0 Atlas Blind
- Bottom L1-L5 Atlas Blind
- Layer Control
- Opacity Slider / Dial
- Evidence Strip
- Coordinate Inspector
- L0 Journey Map
- L1 Route Map
- L2 Workflow Map
- L3 Data Map
- L4 Integration Map
- L5 AI / Ops Map
- Review Queue Overlay
- Resolve URL Command
- Context Packet Preview
- Shareable Diagram Card
- Export Modal
- Screenshot-Ready AI Context View
- Standalone Atlas Overview Dashboard

## Visual identity

ContextAtlas should feel like ancient mapmaking for the AI age.

The visual system should combine:

- spherical wireframes
- connected network nodes
- coordinate lines
- cartographic arcs
- topological maps
- precision drafting
- subtle mathematical compass geometry
- modern SaaS clarity
- premium dark-mode surfaces

It should not feel like:

- generic SaaS dashboard
- crypto/web3 logo
- cyberpunk overload
- map-pin app
- ordinary diagramming software
- observability clone
- AI chatbot wrapper

## Logo direction

The primary mark is a connected `cA` monogram inside or interacting with a networked sphere.

The lowercase `c` and uppercase `A` must always remain connected.

The `c` can feel like:

- a partial globe
- an orbital arc
- a route line
- an unfinished context ring
- a coordinate contour

The `A` can incorporate the geometry of a mathematical compass, but the compass shape must be native to the A.

Do not add a separate compass icon.

The A may include:

- a subtle pivot point
- a compass-like apex
- drafting guide lines
- internal arcs
- a central coordinate node
- a crossbar that connects back into the c

The mark should suggest:

The A is helping complete the c into a mapped sphere.

## Colour palette

Primary dark mode:

- Void black: #05060A
- Deep space charcoal: #080A12
- Obsidian navy: #101827
- Dark slate: #1A2130

Primary luminous palette:

- Electric indigo: #3548FF
- Atlas violet: #7B3FF2
- Coordinate magenta: #D946EF
- Signal cyan: #22D3EE

Cartographic accent palette:

- Brass gold: #C89B3C
- Antique gold: #A8792A
- Soft parchment: #F3EAD8
- Warm ivory: #FAF6EC

Neutral UI palette:

- Graphite: #2A2F3A
- Fine line grey: #445064
- Mist grey: #A7B0C0
- White: #FFFFFF

Gradients are allowed for:

- logo
- network sphere
- active nodes
- selected coordinates
- topological maps
- dark hero surfaces

Avoid cheap rainbow gradients. Keep gradients precise, atmospheric, and premium.

## Typography

Use a precise modern sans-serif for the interface.

Recommended UI fonts:

- Inter
- Geist
- Manrope
- IBM Plex Sans

Recommended display fonts:

- Space Grotesk
- Sora
- IBM Plex Sans

Optional cartographic/editorial accent fonts for rare ceremonial use:

- Cormorant Garamond
- Literata
- Cinzel

The cA logo mark can be more distinctive, with a geometric or serif-inspired A, but the UI should remain clean and readable.

Avoid playful rounded fonts, sci-fi novelty fonts, and generic startup type.

## Product UI direction

The UI should feel like a transparent control layer.

Use:

- dark canvases
- glass panels
- frosted overlays
- thin borders
- coordinate labels
- subtle node graphs
- route lines
- small precise controls
- restrained glow
- technical but calm spacing
- elegant pull handles
- compact status chips

The central product or website being mapped should remain visible.

ContextAtlas should not replace the product with a dashboard unless the user explicitly enters a standalone review screen.

## Landing page direction

The landing page should explain the product simply.

Hero idea:

“Map the context before the model guesses.”

Show a live product surface with:

- small Atlas Pin
- top L0 blind partially pulled down
- bottom L1-L5 blind barely visible
- L0 journey map visible as the easiest orientation layer
- coordinate badge copied for AI context

Primary messages:

- Discover topology.
- Classify meaning.
- Generate layered maps.
- Give AI agents coordinates, not a haystack.
- Share the exact layer your team needs.

Avoid vague AI hype.

## Screen priorities for Stitch

Create design-system screens for:

1. Embedded Live App with Collapsed Atlas Tabs
2. Top L0 Blind Pulled Down showing the MAP
3. L0 Journey Map screenshot-ready view
4. Bottom L1-L5 Workbench Blind Pulled Up
5. Both Blinds Active with product surface visible between them
6. Opacity Slider / Dial interaction
7. Coordinate Inspector
8. Resolve URL Command
9. Shareable Diagram Export
10. Human Review Queue Overlay
11. Atlas Overview Dashboard
12. Context Packet Preview

## Accessibility

Dark mode must maintain strong contrast.

Fine network lines must never be the only way to understand information.

Use:

- text labels
- status chips
- selected states
- hover/focus states
- readable contrast
- keyboard-accessible blind controls
- clear snap points

Snap points:

- collapsed
- peek
- half
- full

The opacity slider or dial must be keyboard accessible.

## Tone of voice

Use clear, precise product language.

Preferred phrases:

- Map the context before the model guesses.
- Discover topology.
- Classify meaning.
- Generate layered maps.
- Give AI agents coordinates, not a haystack.
- Turn scattered product knowledge into navigable context.
- Share the exact layer your team needs.
- From URL to user journey to system map.
- The screen becomes the context.

Avoid:

- revolutionary
- game-changing
- 10x
- AI magic
- unlock your potential
- the future of everything

## Use of aiCOVENANTS reference

The uploaded aiCOVENANTS design system is a reference for interaction depth, especially the pull-down tab behaviour.

Use it as inspiration for the idea of revealing hidden layers progressively.

Do not copy the aiCOVENANTS brand, language, covenant concept, colours, typography, or identity.

For ContextAtlas, the pull-down interaction should feel more like blinds:

- subtle pull tab
- smooth reveal
- transparent or frosted overlay
- adjustable opacity
- progressive layer exposure
- L0 map first
- deeper layers only when requested

## What to avoid

Avoid:

- ordinary dashboards as the main product metaphor
- detached compass icons
- generic globe icons
- map pins
- crypto visual language
- overwhelming neon
- dense graphs without labels
- hiding the product surface
- making L0 too technical
- exposing admin/engineering layers in the public map by default
- treating layers as ordinary tabs
- making the blind feel like a modal drawer